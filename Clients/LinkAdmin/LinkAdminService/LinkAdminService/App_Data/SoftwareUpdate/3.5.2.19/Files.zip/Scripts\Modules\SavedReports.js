﻿function RenderSavedReportOptions(sender, directory, idSavedReport) {
    var menu = InitMenu("menuSavedReport" + idSavedReport);

    var lnkPinToHome = document.createElement("div");
    lnkPinToHome.ImageUrl = "/Images/Icons/Menu/Pin.png";
    lnkPinToHome.innerHTML = LoadLanguageText("PinToHomescreen");
    lnkPinToHome.MenuItemClick = "PinToHomescreen('" + idSavedReport + "')";

    menu.Items.push(lnkPinToHome);

    var lnkCopyLink = document.createElement("div");
    lnkCopyLink.ImageUrl = "/Images/Icons/Menu/CopyHyperlink.png";
    lnkCopyLink.innerHTML = LoadLanguageText("CopyHyperlink");
    lnkCopyLink.MenuItemClick = "CopyHyperlink('" + idSavedReport + "')";

    menu.Items.push(lnkCopyLink);

    var lnkConnectPowerBI = document.createElement("div");
    lnkConnectPowerBI.ImageUrl = "/Images/Icons/Menu/ConnectPowerBI.png";
    lnkConnectPowerBI.innerHTML = LoadLanguageText("ConnectPowerBI");
    lnkConnectPowerBI.MenuItemClick = "ConnectPowerBI('" + idSavedReport + "', 'Reporter')";

    menu.Items.push(lnkConnectPowerBI);

    if (typeof (DeleteSavedReport) != "undefined") {
        var lnkDelete = document.createElement("div");
        lnkDelete.ImageUrl = "/Images/Icons/Menu/Delete.png";
        lnkDelete.innerHTML = LoadLanguageText("Delete");
        lnkDelete.MenuItemClick = "DeleteSavedReport(this, '" + directory + "', '" + sender.parentNode.innerText.trim() + "');";

        menu.Items.push(lnkDelete);
    }

    menu.Render();
}

function CopyHyperlink(idSavedReport) {
    try {
        if (window.location.href.indexOf("Default.aspx") > -1) {
            //copyToClipboard(window.location.href.replace("Default.aspx", "LinkReporter/Crosstabs.aspx?SavedReport=") + idSavedReport);
            if (copyToClipboard(window.location.href.replace("Default.aspx", "LinkReporter/Crosstabs.aspx?SavedReport=") + idSavedReport)) {
                ShowMessage(LoadLanguageText("CopyHyperlinkSuccess"), "Success");
            }
        }
        else {
            if (copyToClipboard(window.location.href.replace("LinkCloud.aspx", "LinkReporter/Crosstabs.aspx?SavedReport=") + idSavedReport)) {
                ShowMessage(LoadLanguageText("CopyHyperlinkSuccess"), "Success");
            }
        }

    }
    catch (e) {
        ShowMessage(LoadLanguageText("CopyHyperlinkError"), "Error");
    }
}

function PinToHomescreen(idSavedReport) {
    AjaxRequest("PinToHomescreen", "IdSavedReport=" + idSavedReport, function (response) {
        window.location = "/Pages/Default.aspx";
    });
}