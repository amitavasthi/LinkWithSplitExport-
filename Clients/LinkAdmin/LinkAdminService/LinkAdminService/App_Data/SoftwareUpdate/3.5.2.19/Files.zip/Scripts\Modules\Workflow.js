﻿var workflowSelectionHasChanged = false;

var workflowSelectionRequestsPending = 0;
function SelectAllWorkflowItems(sender) {
    var activeItems = GetChildsByAttribute(sender, "class", "WorkflowSelectorItem WorkflowSelectorItem_Active BackgroundColor1", true);
    var inactiveItems = GetChildsByAttribute(sender, "class", "WorkflowSelectorItem BackgroundColor5H", true);

    if (activeItems.length == 0) {
        for (var i = 0; i < inactiveItems.length; i++) {
            inactiveItems[i].onclick();
        }
    }
    else {
        for (var i = 0; i < activeItems.length; i++) {
            activeItems[i].onclick();
        }
    }
}

function SelectWorkflowItem(selectorItem, source, idWorkflowSelection, workflowSelection, workflowSelectionVariable, service, idItem) {
    var parameters = "Source="+ source +"&WorkflowSelection=" + workflowSelection + "&WorkflowSelectionVariable=" +
        workflowSelectionVariable + "&IdItem=" + idItem + "&Action=";

    if (selectorItem.getAttribute("State") == "Selected") {
        parameters += "DeSelect";

        selectorItem.setAttribute("State", "none");
        selectorItem.className = "WorkflowSelectorItem BackgroundColor5H";
    } else {
        parameters += "Select";

        selectorItem.setAttribute("State", "Selected");
        selectorItem.className = "WorkflowSelectorItem WorkflowSelectorItem_Active BackgroundColor1";
    }

    workflowSelectionHasChanged = true;

    workflowSelectionRequestsPending++;
    _AjaxRequest(service, "SelectWorkflowSelectorItem", parameters, function (response) {
        workflowSelectionRequestsPending--;
    });
}

var workflowSelectionDetailVisible = false;
function ShowWorkflowSelectionDetail(sender) {

    var workflowContainer = GetChildByAttribute(document.getElementById("cphContent_pnlWorkflow"), "class", "Workflow Color1");
    var workflowBackground = document.getElementById("WorkflowBackground");

    if (workflowContainer.offsetHeight > 0) {
        if (workflowSelectionRequestsPending > 0) {
            ShowLoading(workflowContainer);
            window.setTimeout(function () { ShowWorkflowSelectionDetail(sender) }, 500);
            return;
        }

        HideLoading();

        DecreaseOpacity(workflowBackground, function () {
            workflowBackground.style.display = "none";

            if (workflowSelectionHasChanged) {
                workflowSelectionHasChanged = false;

                if(window.location.toString().search("/LinkReporter/Crosstabs.aspx") != -1)
                    ReloadCrosstable();
            }
        });

        DecreaseHeight(workflowContainer, 0, function () {
            if (sender != undefined)
                sender.src = "/Images/Icons/Expand.png";
        });
    }
    else {
        workflowSelectionHasChanged = false;

        workflowBackground.style.opacity = "0.0";
        workflowBackground.style.display = "";

        IncreaseOpacity(workflowBackground, undefined, 0.5);

        var height = parseInt(window.innerHeight / 3);
        IncreaseHeight(workflowContainer, height, function () {
            if (sender != undefined)
                sender.src = "/Images/Icons/Collapse.png";
        });

        var workflowSelections = GetChildsByAttribute(workflowContainer, "class", "WorkflowSelection BorderColor1");

        var width = parseInt(window.innerWidth / workflowSelections.length) - 2;

        // Run through all workflow selections.
        for (var i = 0; i < workflowSelections.length; i++) {
            workflowSelections[i].style.width = width + "px";

            var selector = GetChildByAttribute(workflowSelections[i], "class", "WorkflowSelector", true);

            selector.style.height = (height - 59) + "px";
            selector.style.maxHeight = (height - 59) + "px";
        }


    }
}

function ReloadCrosstable() {
    PopulateCrosstable();
    return;


    var id = "cphContent_pnl";

    //ShowLoading(document.getElementById("Content"));
    ShowLoading(document.body);

    //document.getElementById(id).innerHTML = "<table style='height:100%;width:100%;'><tr><td><img src='/Images/Icons/Loading.gif' /></td></tr></table>"

    AjaxRequest("BuildCrosstable", "", function (response) {
        var container = document.getElementById(id);

        container.innerHTML = response;

        EvaluateScripts(container);

        InitBoxes();
        HideLoading();
        InitNestedLeftVariableSelectors();
        ScrollVariableLabel();
    });
}

function EvaluateScripts(container) {
    var scripts = container.getElementsByTagName("script");

    for (var i = 0; i < scripts.length; i++) {
        var script = scripts.item(i);

        eval(script.innerHTML);
    }
}