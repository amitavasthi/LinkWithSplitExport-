﻿function InitCategorySearch(idControl, selectionType, source) {
    var control = document.getElementById(idControl);

    control.Source = source;

    control.SearchBox = GetChildByAttribute(control, "type", "text", true);
    control.SearchResults = GetChildByAttribute(control, "class", "CategorySearchResults", true);

    control.SearchBox.Control = control;
    control.SearchResults.Control = control;

    control.SearchBox.setAttribute("onkeyup", "document.getElementById('"+ control.id +"').Search();");

    control.SearchResults.style.height = (ContentHeight - 300) + "px";

    control.SelectionType = selectionType;

    control.LastSearchValue = undefined;
    control.ActiveSearchRequests = new Array();
    control.Search = function () {
        var searchValue = "";

        searchValue = control.SearchBox.value;

        if (control.LastSearchValue == searchValue)
            return;

        for (var i = 0; i < control.ActiveSearchRequests.length; i++) {
            control.ActiveSearchRequests[i].abort();
        }

        control.ActiveSearchRequests = new Array();

        control.LastSearchValue = searchValue;

        ShowLoading(control.SearchResults);

        var searchRequest = _AjaxRequest("/Handlers/GlobalHandler.ashx", "SearchCategories", "Id=" + idControl + "&Expression=" + searchValue + "&Source=" + encodeURIComponent(control.Source), function (response, control) {
            
            var index = control.ActiveSearchRequests.indexOf(searchRequest);
            if (index > -1) {
                control.ActiveSearchRequests.splice(index, 1);
            }

            control.SelectedItems = new Array();
            var searchValue = control.SearchBox.value;

            var split = response.split("##################SPLIT##################");

            if (split[0] != searchValue.trim())
                return;

            control.SearchResults.innerHTML = split[1];

            InitBoxes();
        }, control);
        control.ActiveSearchRequests.push(searchRequest);
    };

    control.SelectedItems = new Array();

    control.SelectionChanged = undefined;

    control.UpdateSelectedItems = function (confirmed) {
        control.SelectedItems = new Array();

        var inputs = control.SearchResults.getElementsByTagName("input");

        for (var i = 0; i < inputs.length; i++) {
            if (!inputs.item(i).checked)
                continue;

            control.SelectedItems.push({
                Id: inputs.item(i).getAttribute("IdCategory"),
                VariableName: inputs.item(i).getAttribute("VariableName"),
                Name: inputs.item(i).getAttribute("CategoryName"),
                IsTaxonomy: inputs.item(i).getAttribute("IsTaxonomy"),
                IdStudy: inputs.item(i).getAttribute("IdStudy")
            });
        }

        if (control.SelectionChanged != undefined)
            control.SelectionChanged();
    };

    control.Select = function (idCategory) {
        var inputs = control.SearchResults.getElementsByTagName("input");

        for (var i = 0; i < inputs.length; i++) {
            if (inputs.item(i).getAttribute("IdCategory") != idCategory.toString())
                continue;

            inputs.item(i)["Image"].onclick();
        }
    };

    control.Close = function (confirmed) {
        if (confirmed == true && control.OnConfirm != undefined)
            control.OnConfirm(control);
        else if (confirmed == false && control.OnCancel != undefined)
            control.OnCancel();
    };

    control.Search();
}

function ToggleSearchCategoryItem(sender) {
    sender.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.UpdateSelectedItems();

    if (sender.checked) {
        sender.parentNode.className = "";
        sender.parentNode.style.color = "";
    }
    else {
        sender.parentNode.className = "";
        sender.parentNode.style.color = "";
    }
}