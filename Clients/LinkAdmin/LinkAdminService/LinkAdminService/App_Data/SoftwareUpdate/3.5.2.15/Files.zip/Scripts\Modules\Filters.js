﻿var filtersChanged = false;

function EnableFilterCategorySearch(sender, fileName, path) {
    InitDragBox('boxFilterSearchControl', 'Top');

    var background = GetChildByAttribute(document.getElementById("boxFilterSearch"), "class", "BoxBackground");
    background.style.zIndex = 10000;
    document.getElementById("boxFilterSearchControl").style.zIndex = 10001;

    var categorySearch = document.getElementById("cphContent_csFilterDefinition");

    categorySearch.LastSearchValue = undefined;
    categorySearch.Search();

    categorySearch.OnConfirm = function () {
        DisableFilterCategorySearch(fileName, path);
    };
    categorySearch.OnCancel = function () {
        CloseBox("boxFilterSearchControl", "Top");
    };
}

function DisableFilterCategorySearch(fileName, path) {

    var requests = 0;

    var taxonomyCategories = "";
    var categories = "";

    var categorySearch = document.getElementById("cphContent_csFilterDefinition");

    for (var i = 0; i < categorySearch.SelectedItems.length; i++) {
        if (categorySearch.SelectedItems[i].IsTaxonomy == "false") {
            categories += categorySearch.SelectedItems[i].Id + ",";
        }
        else {
            taxonomyCategories += categorySearch.SelectedItems[i].Id + ",";
        }
    }

    if (taxonomyCategories.length > 0) {
        AjaxRequest("AddFilterCategories", "FileName=" + fileName + "&XPath=" + path + "&Type=" + "ReportDefinitionTaxonomyCategory" + "&Categories=" + taxonomyCategories, function (response) {
            filtersChanged = true;

            UpdateFilterView(fileName);
        });
    }

    if (categories.length > 0) {
        AjaxRequest("AddFilterCategories", "FileName=" + fileName + "&XPath=" + path + "&Type=" + "ReportDefinitionCategory" + "&Categories=" + categories, function (response) {
            filtersChanged = true;

            UpdateFilterView(fileName);
        });
    }

    CloseBox("boxFilterSearchControl", "Top");
}

function SearchFilterCategories(sender) {
    var searchValue = "";

    if (sender != undefined)
        searchValue = sender.value;

    AjaxRequest("SearchFilterCategories", "Expression=" + searchValue, function (response) {
        var result = JSON.parse(response);

        var searchValue = "";

        if (sender != undefined)
            searchValue = sender.value;

        if (result.SearchExpression != searchValue)
            return;

        var filterSearchResults = document.getElementById("filterSearchResults");
        filterSearchResults.innerHTML = "";

        for (var i = 0; i < result.Results.length; i++) {
            var html = "";

            html += "<table cellspacing=\"0\" cellpadding=\"0\"><tr><td class=\"FilterSearchResultVariable BackgroundColor1\" colspan=\"2\">" + result.Results[i].Label + "</td></tr>";

            for (var c = 0; c < result.Results[i].Categories.length; c++) {
                html += "<tr><td class=\"BackgroundColor1\" style=\"width:20px\"><td><input IsTaxonomy=\"" + result.Results[i].IsTaxonomy + "\" IdCategory=\"" + result.Results[i].Categories[c].Id + "\" type=\"checkbox\" onclick=\"ToggleFilterSearchCategory(this);\" />" + result.Results[i].Categories[c].Label + "</td></tr>";
            }

            html += "</table>";

            filterSearchResults.innerHTML += html;
        }
    });
}

function ToggleFilterSearchCategory(sender) {
    if (sender.checked) {
        sender.parentNode.className = "GreenBackground";
        sender.parentNode.style.color = "#FFFFFF";
    }
    else {
        sender.parentNode.className = "";
        sender.parentNode.style.color = "";
    }
}

function UpdateFilterView(fileName) {
    AjaxRequest("UpdateFilterView", "FileName=" + fileName, function (response) {
        var control = document.getElementById("cphContent_pnlFilterCategories");

        if (control == undefined)
            alert("Wrong ID");

        control.innerHTML = response;

        EvaluateScripts(control);

        HideLoading();
    });
}

function ChangeFilterCategoryOperator(fileName, xPath, type) {
    var pnl = document.getElementById("boxFilterControl");

    if (pnl != undefined)
        ShowLoading(pnl);

    filtersChanged = true;

    AjaxRequest("ChangeFilterCategoryOperator", "Type=" + type + "&FileName=" + fileName + "&XPath=" + xPath, function (response) {
        UpdateFilterView(fileName);
    });
}

function AddFilterCategory(fileName, xPath, idCategory, type) {
    var pnl = document.getElementById("boxFilterControl");

    if (pnl != undefined)
        ShowLoading(pnl);

    filtersChanged = true;

    AjaxRequest("AddFilterCategory", "IdCategory=" + idCategory + "&FileName=" + fileName + "&XPath=" + xPath + "&Type=" + type, function (response) {
        UpdateFilterView(fileName);
    });
}

function DeleteFilterCategory(fileName, xPath, idCategory) {
    var pnl = document.getElementById("boxFilterControl");

    if (pnl != undefined)
        ShowLoading(pnl);

    filtersChanged = true;

    AjaxRequest("DeleteFilterCategory", "IdCategory=" + idCategory + "&FileName=" + fileName + "&XPath=" + xPath, function (response) {
        UpdateFilterView(fileName);
    });
}

function AddFilterCategoryOperator(fileName, xPath) {
    var pnl = document.getElementById("boxFilterControl");

    if (pnl != undefined)
        ShowLoading(pnl);

    AjaxRequest("AddFilterCategoryOperator", "XPath=" + xPath + "&FileName=" + fileName, function (response) {
        UpdateFilterView(fileName);
    });
}

function DeleteFilterCategoryOperator(fileName, xPath) {
    var pnl = document.getElementById("boxFilterControl");

    if (pnl != undefined)
        ShowLoading(pnl);

    filtersChanged = true;

    AjaxRequest("DeleteFilterCategoryOperator", "XPath=" + xPath + "&FileName=" + fileName, function (response) {
        UpdateFilterView(fileName);
    });
}