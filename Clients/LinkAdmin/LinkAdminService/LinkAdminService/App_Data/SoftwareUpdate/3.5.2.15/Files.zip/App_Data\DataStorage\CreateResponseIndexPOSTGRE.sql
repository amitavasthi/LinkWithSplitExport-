CREATE INDEX "IX_Var_{0}" ON "resp"."Var_{0}"
(
	[IdCategory] ASC
)WITH (FASTUPDATE = OFF)
