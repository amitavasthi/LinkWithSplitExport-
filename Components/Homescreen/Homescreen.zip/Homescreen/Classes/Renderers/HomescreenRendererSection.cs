﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homescreen1.Classes.Renderers
{
    public class HomescreenRendererSection : HomescreenRenderer
    {
        #region Properties

        /// <summary>
        /// Gets the amount of sections in the line.
        /// </summary>
        public int SectionCount
        {
            get
            {
                if (this.Node.XmlNode.Attributes["SectionCount"] == null)
                    return 1;

                return int.Parse(this.Node.XmlNode.Attributes["SectionCount"].Value);
            }
        }

        /// <summary>
        /// Gets where the section is docked.
        /// </summary>
        public HomescreenSectionDock Dock
        {
            get
            {
                if (this.Node.XmlNode.Attributes["Dock"] == null)
                    return HomescreenSectionDock.Left;

                return (HomescreenSectionDock)Enum.Parse(
                    typeof(HomescreenSectionDock),
                    this.Node.XmlNode.Attributes["Dock"].Value
                );
            }
        }

        public int Height { get; set; }

        #endregion


        #region Constructor

        /// <summary>
        /// Creates a new instance of the section renderer.
        /// </summary>
        /// <param name="node">The node to render.</param>
        public HomescreenRendererSection(HomescreenNode node)
            : base(node)
        { }

        #endregion


        #region Methods

        public int CalculateHeight()
        {
            this.Height = this.Node.Height;

            if (this.Node.XmlNode.Attributes["Height"] != null)
            {
                this.Height = int.Parse(this.Node.XmlNode.Attributes["Height"].Value);

            }
            else if (this.Dock == HomescreenSectionDock.Top || this.Dock == HomescreenSectionDock.Bottom)
            {
                this.Height = this.Node.Owner.ContentHeight;

                List<HomescreenNode> neighbors;

                if (this.Node.Parent != null)
                    neighbors = this.Node.Parent.ChildNodes;
                else
                    neighbors = this.Node.Owner.Nodes;

                foreach (HomescreenNode neighbor in neighbors)
                {
                    if (neighbor.XmlNode.Attributes["Height"] != null)
                        this.Height -= int.Parse(neighbor.XmlNode.Attributes["Height"].Value);
                }
            }

            if (this.Node.XmlNode.Attributes["Title"] != null)
            {
                this.Height -= 45;
            }

            return this.Height;
        }

        public override void RenderBegin(StringBuilder writer)
        {
            int height = this.Height;

            if (this.Node.XmlNode.Attributes["Title"] != null)
                height += 45;

            // Open the section's div tag.
            writer.Append(string.Format(
                "<div class=\"Section Section{0}\" style=\"width:{1}%;{2}\">",
                this.Node.Name,
                100 / this.SectionCount,
                "height:" + height + "px;"
            ));

            if (this.Node.XmlNode.Attributes["Title"] != null)
            {
                writer.Append(string.Format(
                    "<h1 class=\"Color1\">{0}</h1>",
                    this.Node.Owner.LanguageManager.GetText(this.Node.XmlNode.Attributes["Title"].Value)
                ));
            }
        }

        public override void RenderEnd(StringBuilder writer)
        {
            // Close the section's div tag.
            writer.Append("</div>");
        }

        #endregion
    }

    public enum HomescreenSectionDock
    {
        Left,
        Middle,
        Right,
        Top,
        Bottom
    }
}
