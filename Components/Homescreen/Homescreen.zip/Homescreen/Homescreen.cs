﻿using Homescreen1.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI;
using System.Xml;

namespace Homescreen1
{
    public class Homescreen : WebUtilities.BaseControl
    {
        #region Properties

        /// <summary>
        /// Gets or sets the full path to
        /// the homescreen definition file.
        /// </summary>
        public string FileName { get; set; }

        /// <summary>
        /// Gets or sets a list of homescreen nodes on root level.
        /// </summary>
        public List<HomescreenNode> Nodes { get; set; }

        /// <summary>
        /// Gets or sets the available height for the homescreen.
        /// </summary>
        public int ContentHeight { get; set; }

        /// <summary>
        /// Gets or sets the available width for the homescreen.
        /// </summary>
        public int ContentWidth { get; set; }

        #endregion


        #region Constructor

        public Homescreen(string fileName)
        {
            this.FileName = fileName;

            this.Parse();

            this.Load += Homescreen_Load;
        }

        #endregion


        #region Methods

        private void Parse()
        {
            // Create a new list that stores the
            // homescreen nodes on root level.
            this.Nodes = new List<HomescreenNode>();

            // Create a new xml document that
            // contains the homescreen's definitions.
            XmlDocument document = new XmlDocument();

            // Load the contents of the homescreen
            // definition file into the xml document.
            document.Load(this.FileName);

            // Run through all child nodes of the
            // homescreen definition's document node.
            foreach (XmlNode xmlNode in document.DocumentElement.ChildNodes)
            {
                // Create a new homescreen node by the xml node.
                HomescreenNode node = new HomescreenNode(xmlNode, this);

                node.Height = this.ContentHeight;

                // Add the homescreen node to the homescreens root nodes.
                this.Nodes.Add(node);
            }
        }

        #endregion


        #region Event Handlers

        protected void Homescreen_Load(object sender, EventArgs e)
        {
            // Create a new string builder as html writer.
            StringBuilder writer = new StringBuilder();

            // Run through all homescreen nodes on root level.
            foreach (HomescreenNode node in this.Nodes)
            {
                // Render the homescreen node.
                node.Render(writer);
            }

            this.Controls.Add(new LiteralControl(writer.ToString()));
        }

        #endregion
    }
}
